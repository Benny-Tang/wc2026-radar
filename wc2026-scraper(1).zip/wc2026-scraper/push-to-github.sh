#!/bin/bash
# WC2026 Radar — one-click push to GitHub
# Run this from the folder containing this script

set -e

REPO="https://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@github.com/Benny-Tang/wc2026-radar.git"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "╔══════════════════════════════════════╗"
echo "║  WC2026 Radar → GitHub Push           ║"
echo "╚══════════════════════════════════════╝"

# Init git if needed
cd "$SCRIPT_DIR"
if [ ! -d ".git" ]; then
  git init
  git branch -M main
fi

# Set remote
git remote remove origin 2>/dev/null || true
git remote add origin "$REPO"

# Stage everything
git add .
git commit -m "🚀 initial: WC2026 Radar — Bright Data scraper + GitHub Pages dashboard" 2>/dev/null || \
git commit --allow-empty -m "🚀 initial: WC2026 Radar"

# Push
echo "📤 Pushing to github.com/Benny-Tang/wc2026-radar ..."
git push -u origin main --force

echo ""
echo "✅ Done! Now:"
echo "   1. Go to: https://github.com/Benny-Tang/wc2026-radar/settings/pages"
echo "      → Source: main branch, /docs folder → Save"
echo "   2. Go to: https://github.com/Benny-Tang/wc2026-radar/settings/secrets/actions"
echo "      → New secret: BRIGHT_DATA_API_KEY = your_new_bd_key"
echo "   3. Go to: https://github.com/Benny-Tang/wc2026-radar/actions"
echo "      → WC2026 Scraper → Run workflow"
echo ""
echo "   Dashboard: https://benny-tang.github.io/wc2026-radar/"
